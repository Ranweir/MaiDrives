# Build the Android APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this project ZIP to it (the files inside the `drive-game-main` folder, not the outer folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`/`master`).
4. When the run completes, open it and download the `Mai-Shiranui-Drive-debug-apk` artifact. Extract it to get `app-debug.apk`.

This workflow builds the existing driving game as an Android debug APK. The Mai Shiranui 3D character and animation are not yet integrated: the DFF/TXD model and animation ZIP must be re-uploaded and converted/rigged first.
