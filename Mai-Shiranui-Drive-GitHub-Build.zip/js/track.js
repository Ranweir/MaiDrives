// Track geometry: frames (tangent/right/roll), curvature, banking,
// and fast analytic surface queries for the physics raycasts.
import * as THREE from 'three';

// Track width is per-track (set via setTrackWidth before building). These are
// `let` exports so ES module live-bindings propagate the value to every file
// (world/physics/raceline) that imports them — set once at boot, read at build.
export let ROAD_HALF = 4.5;       // asphalt half width (m)
export let CURB_W = 0.7;          // curb width beyond asphalt
export let RAIL_D = 7.2;          // guardrail lateral distance from centerline
export let WALL_D = 6.9;          // physics wall distance

export function setTrackWidth(roadHalf) {
  ROAD_HALF = roadHalf;
  CURB_W = roadHalf < 4 ? 0.5 : 0.7;       // narrower kerbs on a kart track
  RAIL_D = roadHalf + 2.7;                  // keep the same edge offsets
  WALL_D = roadHalf + 2.4;
}

export const SURF = { ROAD: 0, CURB: 1, GRASS: 2 };

export class Track {
  constructor(data) {
    this.name = data.name;
    this.step = data.step;
    this.n = data.points.length;
    this.total = this.n * this.step;
    this.segments = data.segments;

    const n = this.n;
    this.px = new Float32Array(n); this.py = new Float32Array(n); this.pz = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      this.px[i] = data.points[i][0];
      this.py[i] = data.points[i][1];
      this.pz[i] = data.points[i][2];
    }

    // tangents (3D, normalized) and horizontal right vectors
    this.tx = new Float32Array(n); this.ty = new Float32Array(n); this.tz = new Float32Array(n);
    this.rx = new Float32Array(n); this.rz = new Float32Array(n);
    this.curv = new Float32Array(n);   // signed, >0 = left turn
    for (let i = 0; i < n; i++) {
      const a = (i - 1 + n) % n, b = (i + 1) % n;
      let dx = this.px[b] - this.px[a], dy = this.py[b] - this.py[a], dz = this.pz[b] - this.pz[a];
      const L = Math.hypot(dx, dy, dz) || 1;
      this.tx[i] = dx / L; this.ty[i] = dy / L; this.tz[i] = dz / L;
      const hl = Math.hypot(dx, dz) || 1;
      // right = cross(t_horiz, up) = (-tz, 0, tx) normalized
      this.rx[i] = -(dz / hl); this.rz[i] = dx / hl;
    }
    for (let i = 0; i < n; i++) {
      const a = (i - 1 + n) % n, b = (i + 1) % n;
      // cross(t[a], t[b]).y > 0 -> left turn
      const cy = this.tz[a] * this.tx[b] - this.tx[a] * this.tz[b];
      this.curv[i] = Math.asin(THREE.MathUtils.clamp(cy, -1, 1)) / (2 * this.step);
    }
    this._smooth(this.curv, 7, 2);

    // banking: bank into the corner. Karussell sections get the concrete-bowl treatment.
    const karussell = new Float32Array(n);
    for (const [si, seg] of data.segments.entries()) {
      if (/Karussell/i.test(seg.name)) {
        const s0 = seg.s;
        const s1 = si + 1 < data.segments.length ? data.segments[si + 1].s : this.total;
        for (let s = s0; s < s1; s += this.step) karussell[Math.floor(s / this.step) % n] = 1;
      }
    }
    this.roll = new Float32Array(n);  // >0 = right side up (left edge low) = banking for LEFT turn
    for (let i = 0; i < n; i++) {
      const k = Math.abs(this.curv[i]);
      const base = Math.atan(k * 900 / 9.81) * 0.45;          // design speed 30 m/s, 45% banked
      const cap = karussell[i] ? 0.28 : 0.10;                  // 16deg in Karussell, 5.7deg elsewhere
      const mag = Math.min(base * (karussell[i] ? 3.0 : 1.0), cap);
      this.roll[i] = this.curv[i] > 0 ? mag : -mag;
    }
    this._smooth(this.roll, 13, 2);
    this.kar = karussell;             // concrete-slab zones (bump character)

    // per-section surface roughness (the Ring is not uniformly smooth)
    const ROUGH = {
      'Döttinger Höhe': 0.5, 'Antoniusbuche': 0.6, 'Tiergarten': 0.7,
      'Kesselchen': 1.25, 'Bergwerk': 1.2, 'Brünnchen': 1.3,
      'Pflanzgarten': 1.55, 'Sprunghügel': 1.6, 'Stefan-Bellof-S': 1.4,
      'Wippermann': 1.35, 'Eschbach': 1.25, 'Hatzenbach': 1.2,
    };
    this.rough = new Float32Array(n).fill(1);
    for (let si = 0; si < data.segments.length; si++) {
      const f = ROUGH[data.segments[si].name];
      if (f == null) continue;
      const s0 = data.segments[si].s;
      const s1 = si + 1 < data.segments.length ? data.segments[si + 1].s : this.total;
      for (let s = s0; s < s1; s += this.step) this.rough[Math.floor(s / this.step) % n] = f;
    }
    this._smooth(this.rough, 41, 1);

    // curb zones: dilated high-curvature regions
    this.curb = new Uint8Array(n);
    for (let i = 0; i < n; i++) if (Math.abs(this.curv[i]) > 0.011) this.curb[i] = 1;
    const dil = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      for (let k = -6; k <= 6; k++) if (this.curb[(i + k + n) % n]) { dil[i] = 1; break; }
    }
    this.curb = dil;

    // spatial hash grid (25m cells)
    this.cell = 25;
    this.grid = new Map();
    for (let i = 0; i < n; i++) {
      const key = Math.floor(this.px[i] / this.cell) + '|' + Math.floor(this.pz[i] / this.cell);
      let arr = this.grid.get(key);
      if (!arr) this.grid.set(key, arr = []);
      arr.push(i);
    }
    this._bp = { a: -1, da2: Infinity, b: -1, db2: Infinity };   // branchPair scratch

    // bridge mask: a figure-8 crossover (Everland) has the centreline actually
    // CROSSING itself in plan view, one branch bridging over the other. Mark
    // the upper (deck) indices around each true 2D intersection. Proximity
    // alone is NOT enough — hairpin switchbacks also run close with height
    // difference, and those must keep their normal skirts/terrain.
    this.bridge = new Uint8Array(n);
    const FARB = Math.max(12, Math.round(60 / this.step));
    for (let i = 0; i < n; i++) {
      const j1 = (i + 1) % n;
      const ax = this.px[i], az = this.pz[i], bx = this.px[j1], bz = this.pz[j1];
      const cgx = Math.floor(ax / this.cell), cgz = Math.floor(az / this.cell);
      for (let gx = cgx - 1; gx <= cgx + 1; gx++) {
        for (let gz = cgz - 1; gz <= cgz + 1; gz++) {
          const arr = this.grid.get(gx + '|' + gz);
          if (!arr) continue;
          for (const j of arr) {
            let ad = Math.abs(i - j); ad = Math.min(ad, n - ad);
            if (ad < FARB) continue;
            const j2 = (j + 1) % n;
            const cx = this.px[j], cz = this.pz[j], dx2 = this.px[j2], dz2 = this.pz[j2];
            const rX = bx - ax, rZ = bz - az, sX = dx2 - cx, sZ = dz2 - cz;
            const den = rX * sZ - rZ * sX;
            if (Math.abs(den) < 1e-9) continue;
            const t = ((cx - ax) * sZ - (cz - az) * sX) / den;
            const u = ((cx - ax) * rZ - (cz - az) * rX) / den;
            if (t < 0 || t > 1 || u < 0 || u > 1) continue;
            // a real deck needs vertical separation — an at-grade crossing
            // (flat kart figure-8) shares one surface and keeps its skirts
            if (Math.abs(this.py[i] - this.py[j]) < 2.5) continue;
            const hi = this.py[i] > this.py[j] ? i : j;   // upper branch = deck
            const R = Math.round(30 / this.step);          // deck + approaches
            for (let k = -R; k <= R; k++) this.bridge[(hi + k + n) % n] = 1;
          }
        }
      }
    }
  }

  _smooth(arr, win, passes) {
    const n = arr.length, half = win >> 1;
    for (let p = 0; p < passes; p++) {
      const out = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        let s = 0;
        for (let k = -half; k <= half; k++) s += arr[(i + k + n) % n];
        out[i] = s / (2 * half + 1);
      }
      arr.set(out);
    }
  }

  // Nearest centerline index per BRANCH: `a` is the global nearest, `b` the
  // nearest point that is arc-far from `a` (>60 m along the lap) — i.e. a
  // different section of track passing nearby (crossover bridge, close
  // parallel legs). b = -1 when no second branch is in range.
  // Returns a shared scratch object — consume before the next call.
  branchPair(x, z, maxRing = 4) {
    const cx = Math.floor(x / this.cell), cz = Math.floor(z / this.cell);
    const bp = this._bp;
    let a = -1, da2 = Infinity;
    let hitRing = -1;
    for (let ring = 0; ring <= maxRing; ring++) {
      for (let gx = cx - ring; gx <= cx + ring; gx++) {
        for (let gz = cz - ring; gz <= cz + ring; gz++) {
          if (ring > 0 && Math.abs(gx - cx) !== ring && Math.abs(gz - cz) !== ring) continue;
          const arr = this.grid.get(gx + '|' + gz);
          if (!arr) continue;
          for (const i of arr) {
            const dx = this.px[i] - x, dz = this.pz[i] - z;
            const d = dx * dx + dz * dz;
            if (d < da2) { da2 = d; a = i; }
          }
        }
      }
      if (hitRing < 0 && a >= 0) hitRing = ring;
      if (hitRing >= 0 && ring >= hitRing + 1) break;   // one extra ring after first hit
    }
    bp.a = a; bp.da2 = da2; bp.b = -1; bp.db2 = Infinity;
    if (a < 0) return bp;
    // second pass over the same rings for the arc-far branch
    const n = this.n, FAR = Math.max(12, Math.round(60 / this.step));
    const lastRing = Math.min(maxRing, hitRing + 1);
    for (let ring = 0; ring <= lastRing; ring++) {
      for (let gx = cx - ring; gx <= cx + ring; gx++) {
        for (let gz = cz - ring; gz <= cz + ring; gz++) {
          if (ring > 0 && Math.abs(gx - cx) !== ring && Math.abs(gz - cz) !== ring) continue;
          const arr = this.grid.get(gx + '|' + gz);
          if (!arr) continue;
          for (const i of arr) {
            let ad = Math.abs(i - a); ad = Math.min(ad, n - ad);
            if (ad < FAR) continue;
            const dx = this.px[i] - x, dz = this.pz[i] - z;
            const d = dx * dx + dz * dz;
            if (d < bp.db2) { bp.db2 = d; bp.b = i; }
          }
        }
      }
    }
    return bp;
  }

  // nearest centerline index to (x,z). With `yRef` (a world height), branch
  // selection is height-aware: at a crossover the branch nearest to yRef wins
  // (weighted so the ~7 m deck separation dominates road-width ambiguity).
  nearestIndex(x, z, maxRing = 4, yRef) {
    const bp = this.branchPair(x, z, maxRing);
    if (bp.a < 0 || bp.b < 0 || yRef === undefined) return bp.a;
    const da = bp.da2 + 3 * (this.py[bp.a] - yRef) * (this.py[bp.a] - yRef);
    const db = bp.db2 + 3 * (this.py[bp.b] - yRef) * (this.py[bp.b] - yRef);
    return db < da ? bp.b : bp.a;
  }

  // nearest index for GROUND purposes: under a crossover deck the single-valued
  // terrain must follow the LOWER branch so the underpass stays open. Gated on
  // the bridge mask — close parallel legs (hairpins) keep normal behaviour.
  nearestIndexLow(x, z, maxRing = 4) {
    const bp = this.branchPair(x, z, maxRing);
    if (bp.b >= 0 && bp.db2 < 30 * 30 && this.bridge[bp.a] &&
        this.py[bp.b] < this.py[bp.a] - 2) return bp.b;
    return bp.a;
  }

  // Full surface query at world (x,z).
  // `yRef` (optional world height) disambiguates overlapping branches at a
  // crossover — physics/camera callers pass their y so the bridge deck and the
  // underpass resolve to their own surface.
  // Returns {s, d, y, nx,ny,nz, tx,ty,tz, surf, i, roll} or null if far off-track.
  query(x, z, out, yRef) {
    const i0 = this.nearestIndex(x, z, 4, yRef);
    if (i0 < 0) return null;
    return this._surface(i0, x, z, out);
  }

  // ground variant: overlapping branches resolve to the lower one (underpass)
  queryGround(x, z, out) {
    const i0 = this.nearestIndexLow(x, z);
    if (i0 < 0) return null;
    return this._surface(i0, x, z, out);
  }

  _surface(i0, x, z, out) {
    const n = this.n;
    // project on the two adjacent segments (horizontal), keep the closer
    let bi = i0, bt = 0, bd2 = Infinity;
    for (const i of [(i0 - 1 + n) % n, i0]) {
      const j = (i + 1) % n;
      const ax = this.px[i], az = this.pz[i];
      const bx = this.px[j], bz = this.pz[j];
      const ex = bx - ax, ez = bz - az;
      const L2 = ex * ex + ez * ez || 1;
      const t = THREE.MathUtils.clamp(((x - ax) * ex + (z - az) * ez) / L2, 0, 1);
      const qx = ax + ex * t, qz = az + ez * t;
      const d2 = (x - qx) * (x - qx) + (z - qz) * (z - qz);
      if (d2 < bd2) { bd2 = d2; bi = i; bt = t; }
    }
    const j = (bi + 1) % n;
    const lerp = (A, B) => A + (B - A) * bt;
    const cx = lerp(this.px[bi], this.px[j]), cy = lerp(this.py[bi], this.py[j]), cz2 = lerp(this.pz[bi], this.pz[j]);
    let rx = lerp(this.rx[bi], this.rx[j]), rz = lerp(this.rz[bi], this.rz[j]);
    const rl = Math.hypot(rx, rz) || 1; rx /= rl; rz /= rl;
    const roll = lerp(this.roll[bi], this.roll[j]);
    const d = (x - cx) * rx + (z - cz2) * rz;        // signed lateral, + = right of center

    const ad = Math.abs(d);
    let surf, y;
    const tanR = Math.tan(roll);
    // NOTE: every transition below is a continuous ramp — a height step,
    // crossed at speed, spikes the suspension damper and launches the car.
    if (ad <= ROAD_HALF) {
      surf = SURF.ROAD;
      y = cy + d * tanR;
    } else if (ad <= ROAD_HALF + CURB_W && this.curb[bi]) {
      surf = SURF.CURB;
      const lip = Math.min(1, (ad - ROAD_HALF) / 0.25) * 0.025;
      y = cy + d * tanR + lip;
    } else {
      surf = SURF.GRASS;
      const edge = cy + Math.sign(d) * ROAD_HALF * tanR;
      const off = ad - ROAD_HALF;
      const drop = Math.min(1, off / 0.9) * 0.10;    // ramp down over 0.9 m
      y = edge - drop - off * 0.05;
    }

    let tx = lerp(this.tx[bi], this.tx[j]), ty = lerp(this.ty[bi], this.ty[j]), tz = lerp(this.tz[bi], this.tz[j]);
    const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;

    // surface normal = cross(across, tangent), across = right tilted by roll
    const cr = Math.cos(roll), sr = Math.sin(roll);
    const ax2 = rx * cr, ay2 = sr, az2 = rz * cr;
    let nx = ay2 * tz - az2 * ty, ny = az2 * tx - ax2 * tz, nz = ax2 * ty - ay2 * tx;
    if (ny < 0) { nx = -nx; ny = -ny; nz = -nz; }
    const nl = Math.hypot(nx, ny, nz) || 1;

    out = out || {};
    const sOut = ((bi + bt) * this.step) % this.total;
    y += this.bumpAt(sOut, d, surf, bi);
    out.s = sOut;
    out.d = d; out.y = y;
    out.nx = nx / nl; out.ny = ny / nl; out.nz = nz / nl;
    out.tx = tx; out.ty = ty; out.tz = tz;
    out.rx = rx; out.rz = rz;
    out.surf = surf; out.i = bi; out.roll = roll;
    return out;
  }

  // procedural road-surface micro displacement (felt by the suspension).
  // Deterministic by position; left/right wheels see different phases via d.
  // Amplitudes are kept small (<=25mm) and wavelengths >=0.6m so the damper
  // reads them as bumps, never as launch-grade steps.
  bumpAt(s, d, surf, i) {
    if (surf === SURF.CURB) {
      // sawtooth-ish curb ripple, 0.6m pitch
      const p = Math.sin(s * 10.47);
      return 0.015 * Math.max(0, p) * p;
    }
    if (surf === SURF.GRASS) {
      return Math.sin(s * 5.1 + d * 3.3) * 0.013 + Math.sin(s * 1.37 + d) * 0.009;
    }
    // asphalt: layered waviness scaled by section roughness
    const r = this.rough[i];
    let h = (Math.sin(s * 1.7 + d * 2.1) * Math.sin(s * 0.41 + 1.3) * 0.0065 +
             Math.sin(s * 4.3 + d * 0.8) * 0.0035) * r;
    if (this.kar[i]) {
      // Karussell concrete slab joints every ~4m: dug-dug-dug
      const p = Math.max(0, Math.sin(s * 1.5708));
      h += p * p * p * 0.014;
    }
    return h;
  }

  // centerline pose at arc length s
  poseAt(s) {
    s = ((s % this.total) + this.total) % this.total;
    const f = s / this.step;
    const i = Math.floor(f) % this.n, j = (i + 1) % this.n, t = f - Math.floor(f);
    const L = (A, B) => A + (B - A) * t;
    return {
      x: L(this.px[i], this.px[j]), y: L(this.py[i], this.py[j]), z: L(this.pz[i], this.pz[j]),
      tx: L(this.tx[i], this.tx[j]), ty: L(this.ty[i], this.ty[j]), tz: L(this.tz[i], this.tz[j]),
    };
  }

  // lateral edge position used by mesh builders (d in meters from centerline)
  edge(i, d, yOff = 0, v) {
    v = v || new THREE.Vector3();
    const tanR = Math.tan(this.roll[i]);
    v.set(this.px[i] + this.rx[i] * d, this.py[i] + d * tanR + yOff, this.pz[i] + this.rz[i] * d);
    return v;
  }

  sectionAt(s) {
    const segs = this.segments;
    let lo = 0, hi = segs.length - 1, ans = segs.length - 1;
    if (s < segs[0].s) return segs[segs.length - 1];
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (segs[mid].s <= s) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return segs[ans];
  }
}
